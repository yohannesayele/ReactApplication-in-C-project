var __extends = (this && this.__extends) || function (d, b) {
    for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p];
    function __() { this.constructor = d; }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
};
var CommentBox = (function (_super) {
    __extends(CommentBox, _super);
    function CommentBox() {
        _super.apply(this, arguments);
    }
    CommentBox.prototype.render = function () {
        return (<div className="commentBox">
                Hello, world!I am a CommentBox.
            </div>);
    };
    return CommentBox;
}(React.Component));
ReactDOM.render(<CommentBox />, document.getElementById('content'));
