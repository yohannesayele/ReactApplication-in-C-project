﻿using ReactOnVs2015.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Web.UI;

namespace ReactOnVs2015.Controllers
{
    public class HomeController : Controller
    {
        private static readonly IList<CommentModel> _comments;
        private object JsonRequistBehavior;

        static HomeController()
        {
            _comments = new List<CommentModel>()
            {
                new CommentModel
                {
                     Id=1,
                      Author="john",
                       Text="This is react tutorial for the beginnner"
                },
                 new CommentModel
                {
                     Id=2,
                      Author="john2",
                       Text="This is react tutorial for the beginnner2"
                },
                  new CommentModel
                {
                     Id=3,
                      Author="john3",
                       Text="This is react tutorial for the beginnner3"
                },
            };
        }
            public ActionResult Index()
        {
            return View();
        }

        [OutputCache(Location =OutputCacheLocation.None)]
        public ActionResult Comments()
        {
            return(Json(_comments, JsonRequestBehavior.AllowGet));
        }
        [HttpPost]
        public ActionResult AddComment(CommentModel model)
        {
            int id = _comments.Count + 1;
            model.Id = id;
            _comments.Add(model);
            return Content("success");
        }
    }
}